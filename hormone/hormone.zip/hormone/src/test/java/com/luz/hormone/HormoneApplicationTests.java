package com.luz.hormone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HormoneApplicationTests {

    @Test
    void contextLoads() {
    }

}
