package com.luz.hormone.dao;

import com.luz.hormone.entity.MessageEntity;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MessageMapper {
    public List<MessageEntity> all();
}
