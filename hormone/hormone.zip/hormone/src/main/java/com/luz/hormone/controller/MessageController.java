package com.luz.hormone.controller;

import com.luz.hormone.entity.MessageEntity;
import com.luz.hormone.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class MessageController {
    @Autowired
    private MessageService messageService;

    @RequestMapping(value = "getAll")
    public List<MessageEntity>  getAll(){
        return messageService.getAll();
    }
}
