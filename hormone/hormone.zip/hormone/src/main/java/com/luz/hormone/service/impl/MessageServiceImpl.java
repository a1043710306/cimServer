package com.luz.hormone.service.impl;

import com.luz.hormone.dao.MessageMapper;
import com.luz.hormone.entity.MessageEntity;
import com.luz.hormone.redis.JedisClusterConfig;
import com.luz.hormone.service.MessageService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import redis.clients.jedis.JedisCluster;

import java.util.List;
@Service
public class MessageServiceImpl implements MessageService {
    @Autowired
    private MessageMapper messageMapper;
    @Autowired
    private JedisClusterConfig jedisClusterConfig;

    public List<MessageEntity> getAll(){
        JedisCluster jedisCluster=jedisClusterConfig.getJedisCluster();
        jedisCluster.set("sasd","1231");
        return messageMapper.all();
    }
}
