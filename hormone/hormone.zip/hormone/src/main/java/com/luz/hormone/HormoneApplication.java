package com.luz.hormone;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@MapperScan("com.luz.hormone.dao")
@SpringBootApplication
public class HormoneApplication {

    public static void main(String[] args) {
        SpringApplication.run(HormoneApplication.class, args);
    }

}
