package com.luz.hormone.service;

import com.luz.hormone.entity.MessageEntity;

import java.util.List;

public interface MessageService {
    public List<MessageEntity> getAll();
}
